﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hello
{
    /*class Program
    {
        static void Main(string[] args)
        {
           /*Console.WriteLine("Hello!");*/


           /* int i = 10 ;
            Console.WriteLine(i);
            i = 100;
            Console.WriteLine(i);*/

           /* const int i =10;
            Console.WriteLine(i);
            i=100;
            Console.WriteLine(i);*/
  
       // }
   // }


   /* class Program
    {
        enum gradus : int
        {
            min=0,
            krit=72,
            max=100,
        }
        static void Main(string[] args)
        {
            Console.WriteLine("мин темпер=" + (int)gradus.min);
            Console.WriteLine("крит темпер=" + (int)gradus.krit);
            Console.WriteLine("макс темпер=" + (int)gradus.max);
        }
    }*/


    class Program
    {
        static void Main(string[] args)
        {
            /*
            double x = Math.E;
            Console.WriteLine("E={0:##.######}", x);
            */


           /* Console.WriteLine("C Format:{0,14:C} \t{0:C2}", 12345.678);
            Console.WriteLine("D Format:{0,14:D} \t{0:D6}", 123);
            Console.WriteLine("E Format:{0,14:E} \t{0:E8}", 12345.6789);
            Console.WriteLine("G Format:{0,14:G} \t{0:G10}", 12345.6789);
            Console.WriteLine("N Format:{0,14:N} \t{0:N4}", 12345.6789);
            Console.WriteLine("X Format:{0,14:X} ", 1234);
            Console.WriteLine("P Format:{0,14:P} ", 0.9);    
            */


            /*double x = double.Parse(Console.ReadLine()); 
            Console.WriteLine("x={0:##.###}",x);
            */

          /*Z1  Console.Write("a=");
            int a = int.Parse(Console.ReadLine());
            Console.Write("b=");
            int b = int.Parse(Console.ReadLine());
            Console.Write("{0}+{1}={2}",a,b,a+b);
           */


          /*Z2  Console.WriteLine("a=");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("b=");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("{0}+{1}={2}+{3}", a, b, b,a);
           */


          /*Z3  Console.WriteLine("a=");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("b=");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("c=");
            int c = int.Parse(Console.ReadLine());
            Console.WriteLine("{0}+{1}+{2}={3}", a, b, c, a+b+c);
           */


           /*Z4 Console.WriteLine("a=");
            double a = double.Parse(Console.ReadLine());
            Console.WriteLine("b=");
            double b = double.Parse(Console.ReadLine());
            Console.WriteLine("{0:.#}*{1:.#}={2:.#}",a,b,a*b);
           */

           /*Z5 Console.WriteLine("a=");
            double a = double.Parse(Console.ReadLine());
            Console.WriteLine("b=");
            double b = double.Parse(Console.ReadLine());
            Console.WriteLine("{0:.###}/{1:.###}={2:.###}", a, b, a / b);
            */


            Console.Write("a=");
            double a = double.Parse(Console.ReadLine());
            Console.Write("b=");
            double b = double.Parse(Console.ReadLine());
            Console.Write("c=");
            double c = double.Parse(Console.ReadLine());
            Console.WriteLine("({0:.##}+{1:.##})+{2:.##}={0:.##}+({1:.##}+{2:.##})", a, b, c,a,b,c);
        }
    }
    
}
